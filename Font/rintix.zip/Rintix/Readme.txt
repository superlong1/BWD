Thank you for purchasing
https://graphicriver.net/item/rintix-stylized-font/25555680
++++++++++++++++++++++++++++++++++++++++++

Here simple guide you may like to know.

- just open the file and double click on it
- click install
- done

+++++++++++++++++++++++++++++++++++++++++++

The font is include an alternate stylized typeface from A-Z, and you can use it for logo you like.

Feel free to contact us if you have any issued within this font


CreativeKillr
